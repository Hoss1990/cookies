'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Icon, Reveal, Stars } from './ui';
import { useCart } from './Cart';
import { REVIEWS, fmt } from '@/lib/data';

const CORE = [['cookie', 'Chocolat noir 55%', 'Dans nos cookies choco noix et choco addict'], ['restaurant', 'Beurre', 'Pour une pâte fondante et savoureuse'], ['eco', 'Noix & noisettes', 'Dans nos cookies choco noix et choco noisette'], ['spa', 'Vanille', 'Dans tous nos cookies surgelés']];

export default function ProductDetail({ p, others }) {
  const { add, setOpen } = useCart();
  const [img, setImg] = useState(0);
  const [variant, setVariant] = useState(p.variants?.[0].name || '');
  const [qty, setQty] = useState(1);
  const [done, setDone] = useState(false);
  const [fav, setFav] = useState(false);
  const [acc, setAcc] = useState(0);
  const [bar, setBar] = useState(false);
  useEffect(() => {
    const h = () => setBar(window.scrollY > 500);
    h(); window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  const cur = p.variants?.find((v) => v.name === variant);
  const price = cur?.price ?? p.price;
  const item = () => ({ variant, qty, price, img: cur?.img });
  const onAdd = () => { add(p, item()); setDone(true); setTimeout(() => setDone(false), 1800); };
  const ACC = [
    ['grain', 'Ingrédients', p.ing],
    ['info', 'Allergènes & Conseils nutritionnels', p.all],
    ['local_shipping', 'Conservation & Livraison Express', `${p.cons} Livraison : expédition express réfrigérée sous 24h à 48h partout en Tunisie. Retrait offert le jour même à la boulangerie Kanoun & Fils.`],
  ];

  return (
    <div className="pb-20 md:pb-0">
      <div className="mx-auto max-w-[1280px] px-5 md:px-12">
        <nav className="flex items-center gap-2 py-5 text-xs text-cacao/60">
          <Link href="/" className="hover:text-pop">Accueil</Link>/<Link href="/#creations" className="hover:text-pop">{p.cat === 'cuire' ? 'Prêts-à-cuire' : 'Biscuits prêts'}</Link>/<span className="font-semibold text-cacao">{p.name}</span>
        </nav>

        <div className="grid gap-10 lg:grid-cols-2">
          {/* Galerie */}
          <div className="flex flex-col-reverse gap-4 md:flex-row">
            <div className="flex gap-3 md:flex-col">
              {p.gallery.map((g, i) => (
                <button key={i} onClick={() => setImg(i)} className={`h-16 w-16 overflow-hidden rounded-xl border-2 transition hover:scale-105 ${img === i ? 'border-terra' : 'border-transparent opacity-70'}`}>
                  <img src={g} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
            <div className="relative flex-1 overflow-hidden rounded-3xl bg-gradient-to-br from-biscuit to-terrasoft p-4 sm:p-6">
              <div className="flex gap-2">
                <span className="rounded-full bg-cacao px-3 py-1 text-[11px] font-bold text-white">{p.badge}</span>
                {p.cat === 'cuire' && <span className="rounded-full bg-biscuit px-3 py-1 text-[11px] font-semibold">Fournées minute (10 min)</span>}
              </div>
              <button onClick={() => setFav(!fav)} aria-label="Favori" className="absolute right-5 top-5 rounded-full bg-white p-2 shadow transition hover:scale-110 active:scale-90"><Icon n="favorite" fill={fav} className={fav ? 'text-pop' : ''} /></button>
              <img key={img} src={p.gallery[img]} alt={p.name} className="mt-4 aspect-square w-full animate-fadeUp rounded-2xl object-cover shadow-warm" />
              <div className="mt-4 flex justify-between text-xs text-cacao/60"><span>{p.weight}</span><span className="flex items-center gap-1 text-terra"><Icon n="verified" className="!text-[16px]" /> Artisanal</span></div>
            </div>
          </div>

          {/* Infos */}
          <div className="space-y-6">
            {p.rating && <div className="flex items-center gap-2 text-sm"><Stars n={p.rating} /><b>{p.rating.toFixed(1)} / 5</b><span className="text-cacao/60">• {p.reviews} avis vérifiés</span></div>}
            <div>
              <h1 className="font-display text-[38px] font-bold leading-tight md:text-5xl">{p.name}</h1>
              <p className="mt-1 font-display text-2xl italic text-terra">{p.subtitle}</p>
            </div>
            <p className="text-cacao/70">{p.desc}</p>
            <div className="flex items-center gap-3">
              <span className="font-display text-4xl font-bold">{fmt(price)}</span>
              {p.old && <><span className="text-sm text-cacao/50 line-through">{fmt(p.old)}</span><span className="rounded-full bg-terrasoft px-3 py-1 text-xs font-bold text-terra">-{Math.round((1 - p.price / p.old) * 100)}% Lancement</span></>}
            </div>

            {p.variants && (
              <div className="rounded-2xl bg-cream p-5">
                <p className="mb-3 font-display text-lg font-semibold">{p.variantTitle || 'Choix du format'}</p>
                <div className="grid gap-3 sm:grid-cols-3">
                  {p.variants.map((v) => (
                    <button key={v.name} onClick={() => { setVariant(v.name); const k = p.gallery.indexOf(v.img); if (k >= 0) setImg(k); }} className={`rounded-xl border-2 bg-white p-3 text-left transition hover:-translate-y-0.5 ${variant === v.name ? 'border-terra shadow-warm' : 'border-transparent'}`}>
                      <span className="block text-sm font-bold">{v.name}</span><span className="text-xs text-cacao/60">{v.desc}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {p.compo && (
              <div className="rounded-2xl bg-cream p-5">
                <p className="mb-3 font-display text-lg font-semibold">Composition de la box</p>
                <div className="grid grid-cols-3 gap-3">
                  {p.compo.map(([n, t]) => (
                    <div key={t} className="rounded-xl bg-white p-3 text-center transition hover:-translate-y-0.5 hover:shadow-warm"><span className="block font-display text-2xl font-bold text-terra">{n}×</span><span className="text-xs font-semibold">{t}</span></div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <div className="flex items-center rounded-full bg-biscuit px-2">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="p-3 transition hover:text-terra" aria-label="Moins"><Icon n="remove" /></button>
                <span className="w-8 text-center font-bold">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="p-3 transition hover:text-terra" aria-label="Plus"><Icon n="add" /></button>
              </div>
              <button onClick={onAdd} className={`btn flex-1 py-4 text-white ${done ? 'bg-[#16a34a]' : 'bg-cacao hover:-translate-y-0.5 hover:shadow-glow'}`}>
                <Icon n={done ? 'check_circle' : 'shopping_bag'} fill /> {done ? 'Délicieusement Ajouté !' : `Ajouter au Panier • ${fmt(price * qty)}`}
              </button>
            </div>
            <button onClick={() => { add(p, item()); setOpen(true); }} className="btn-ghost w-full"><Icon n="chat" /> Commander maintenant via WhatsApp</button>

            {p.cat === 'cuire' && (
              <div className="rounded-2xl border border-terra/20 bg-terrasoft/50 p-5">
                <div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-terra text-white"><Icon n="cookie" fill /></span><b className="font-display text-lg">Secret du Chef Kanoun</b><span className="rounded-full bg-terra px-2 py-0.5 text-[10px] font-bold uppercase text-white">À chaud</span></div>
                <p className="mt-2 text-sm text-cacao/75">Préchauffez votre four à <b>180°C</b>. Disposez les portions sur une plaque avec papier sulfurisé et enfournez pendant <b>10 à 12 minutes</b> seulement. Laissez tiédir 3 minutes : le cœur sera parfaitement coulant et fondant.</p>
              </div>
            )}

            <div className="divide-y divide-cacao/10 rounded-2xl bg-cream px-5">
              {ACC.map(([ic, t, body], i) => (
                <div key={t}>
                  <button onClick={() => setAcc(acc === i ? -1 : i)} className="flex w-full items-center gap-3 py-4 text-left font-semibold"><Icon n={ic} className="text-terra" />{t}<Icon n="expand_more" className={`ml-auto transition-transform ${acc === i ? 'rotate-180' : ''}`} /></button>
                  <div className={`grid transition-all duration-300 ${acc === i ? 'grid-rows-[1fr] pb-4' : 'grid-rows-[0fr]'}`}><p className="overflow-hidden text-sm text-cacao/70">{body}</p></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <section className="mt-20 bg-cream py-16">
        <div className="mx-auto max-w-[1280px] px-5 md:px-12">
          <Reveal>
            <p className="text-[11px] font-bold uppercase tracking-[.25em] text-terra">Excellence Pâtissière</p>
            <h2 className="mt-1 font-display text-[30px] font-semibold md:text-[40px]">Au cœur de nos créations</h2>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {CORE.map(([ic, t, d], i) => (
              <Reveal key={t} delay={i * 90}>
                <div className="h-full rounded-2xl bg-white p-6 text-center shadow-warm transition hover:-translate-y-1.5">
                  <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-terrasoft text-terra"><Icon n={ic} /></span>
                  <h3 className="mt-3 font-display text-lg font-semibold">{t}</h3><p className="mt-1 text-xs text-cacao/60">{d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1280px] px-5 py-16 md:px-12">
        <Reveal className="flex items-end justify-between">
          <div><p className="text-[11px] font-bold uppercase tracking-[.25em] text-terra">Accompagnements & Douceurs</p><h2 className="mt-1 font-display text-[30px] font-semibold">Vous aimerez aussi</h2></div>
          <Link href="/#creations" className="group hidden items-center gap-1 text-sm font-bold text-terra sm:flex">Voir tout le catalogue <Icon n="arrow_forward" className="!text-[18px] transition group-hover:translate-x-1" /></Link>
        </Reveal>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {others.map((o) => (
            <Reveal key={o.slug}>
              <div className="flex gap-4 rounded-3xl bg-white p-5 shadow-warm transition hover:-translate-y-1 hover:shadow-glow">
                <Link href={`/produit/${o.slug}`} className="relative w-32 shrink-0 overflow-hidden rounded-2xl bg-biscuit sm:w-40"><img src={o.img} alt={o.name} className="h-full w-full object-cover transition duration-500 hover:scale-105" /><span className={`absolute left-2 top-2 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${o.badgeCls}`}>{o.badge}</span></Link>
                <div className="flex flex-1 flex-col gap-2">
                  {o.rating && <span className="flex items-center gap-1 text-xs"><Icon n="star" fill className="text-gold !text-[16px]" /><b>{o.rating.toFixed(1)}</b><span className="text-cacao/60">({o.reviews} avis)</span></span>}
                  <h3 className="font-display text-xl font-semibold">{o.name}</h3>
                  <p className="line-clamp-2 text-sm text-cacao/70">{o.desc}</p>
                  <div className="mt-auto flex items-center justify-between"><b>{fmt(o.price)}</b><Link href={`/produit/${o.slug}`} className="btn-dark !px-4 !py-2 text-xs"><Icon n="add" className="!text-[16px]" /> Découvrir</Link></div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-gradient-to-b from-vanilla to-cream py-16">
        <div className="mx-auto max-w-[1280px] px-5 md:px-12">
          <Reveal className="text-center"><p className="text-[11px] font-bold uppercase tracking-[.25em] text-terra">Expérience Client</p><h2 className="mt-1 font-display text-[30px] font-semibold">Sorti du four, unanime</h2></Reveal>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {REVIEWS.map((r, i) => (
              <Reveal key={r.n} delay={i * 100}>
                <figure className="h-full rounded-3xl bg-white p-6 shadow-warm transition hover:-translate-y-1"><Stars /><blockquote className="mt-3 text-sm italic text-cacao/80">« {r.t} »</blockquote><figcaption className="mt-4 text-sm"><b>{r.n}</b><br /><span className="text-cacao/60">{r.w}</span></figcaption></figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Barre mobile sticky */}
      <div className={`fixed inset-x-0 bottom-0 z-40 flex items-center justify-between gap-3 border-t border-cacao/10 bg-white/95 p-3 shadow-2xl backdrop-blur transition-transform duration-300 md:hidden ${bar ? 'translate-y-0' : 'translate-y-full'}`}>
        <div className="leading-tight"><b className="block">{p.name}</b><span className="text-sm text-cacao/60">{fmt(price * qty)}</span></div>
        <button onClick={() => { add(p, item()); setOpen(true); }} className="btn-dark !py-2.5 text-sm"><Icon n="shopping_bag" fill /> Commander</button>
      </div>
    </div>
  );
}
